package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class WebdriverProgram {
	
	@Test
	public void methodTest()
	{
		System.setProperty("webdriver.gecko.driver", "ExeFiles/geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com");
	}
	

}
