<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TelnetTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d77f3278-3221-445b-a779-d722e6e278e4</testSuiteGuid>
   <testCaseLink>
      <guid>585f385f-87ec-40f4-b39a-5d024f917ec4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyAccountNameInImpersonateUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac15fff7-9d36-471d-98a3-7e696cbeb294</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyAuditLogs_page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>868fdd82-4d83-46c4-9741-4754b11c1b17</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyChangeStatusFunctionalityOfTrunkGroup</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>61f39ec9-d45c-49a5-84d1-d338a0021fe1</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>179fbe97-4fdd-4c5c-bfad-b4459edb9bdb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyCustomerAdminUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3e7c2c1b-3b8b-4e5d-a0fe-c05160ef5f51</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyCustomerNonAdminUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fca1c0d4-e1ad-4981-885c-e8a2da4d062a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyImpersonateForTN_AuditLog</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6e5780ff-70ed-42f6-9143-97b17652d09b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyGrantTelNetPowerAdminRole</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cd7f49c1-57d1-4ccd-9196-4074645197cc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyImpersonatePage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>791c5588-c3e5-4941-9685-f754c8c1d163</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyLengthOfSearchBarOfTelephoneNumber</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9af68d2c-cd06-479e-94cb-6fe3cbca2876</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyMultipleUserAccount</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>92617852-5808-4b98-9aa6-4c8c20924ee7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyMyTNsPage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a72e1a26-02d3-4da5-9eb9-fc613aae40a1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyMyTollFreeNumbersPage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9668c166-14b8-49c1-8e6e-c208fbf280fe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyNewlyCreatedRecord_e911</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>594cadfa-0a2a-4637-b3b0-c109b7b03f89</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifySIPTrunking</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>d89d6ffc-50ed-42c9-bb1e-9dd437852c8d</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>bb330654-0d41-412e-9f39-94cc5be21564</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>a48f42fd-edeb-488d-880e-fd6322dd14f3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifySIPTrunkingExport</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ab63a9be-cd64-40bc-9941-ed9f85797fda</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyTNPowerUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>731aec4a-4e90-4bd1-a2d0-84ea5f27aebf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyUpdatedFields_MyTNsPage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac93fa56-b316-42b4-8564-4d4e87fdfb8c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify_e911_Page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9d461d6c-6968-4917-a69d-f33ce244f9d5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify_MyTNsFieldsOn_e911Page</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
