<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>New Test Suite1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>10</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>1b3c85b6-6367-4ec4-b6fe-f6c1eae2c22d</testSuiteGuid>
   <testCaseLink>
      <guid>fcf84da4-514f-4abe-9c49-d78eece0651a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyUpdatedFields_MyTNsPage</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
