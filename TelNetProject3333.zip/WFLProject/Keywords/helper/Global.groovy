package helper

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import org.openqa.selenium.WebDriver

public class Global {

	static WebDriver driver = null;
	static String url = "https://portaldev2.telnetww.com:9081/sso/clientportal/login"
	static String Username="nandita@mscognition.com"
	static String Password="Telnet\$1100"
	static String trunkGroupName="Level3-TFO_LD TGID103559169 SFLF4500"
	static String phoneNumber="2312089368"
	static String tollFreeNumber="2312050020"
	static String phoneNumberFore911="2484856902"
	static String impesonateUser="nandita@mscognition.com"

	static String UsernameForImpersonate="vishal@mscognition.com"
	static String PasswordForImpersonate="Mosaic@1019"

	static String customeNonAdminUser="dhaval@mscognition.com"
	//static String customeNonAdminPassword="Mosaic@1019"

	/// Customer Admin
	public static String sEmail_CustomerAdmin;
	public static String sAccountName_CustomerAdmin;
	public static String sName_CustomerAdmin;
	public static String sRole_CustomerAdmin;
	public static String sStatus_CustomerAdmin;

}
