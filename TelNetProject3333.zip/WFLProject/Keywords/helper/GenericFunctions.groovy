package helper

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import java.awt.Robot
import java.awt.event.KeyEvent
import java.lang.reflect.Field
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.remote.RemoteWebElement
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.Select
import org.openqa.selenium.support.ui.WebDriverWait

import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.By
public class GenericFunctions {

	static WebDriver driver
	public static void highlightElement(WebDriver driver,WebElement element) {

		//Create object of a JavascriptExecutor interface
		JavascriptExecutor js = (JavascriptExecutor) driver
		//use executeScript() method and pass the arguments
		//Here i pass values based on css style. Yellow background color with solid red color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}


	static void clickOnLinkText(String text) {
		driver = DriverFactory.getWebDriver()
		driver.findElement(By.linkText(text)).click()
	}

	static int GetRowNumByCellContainsTextFromHtmlTable(String tableXpath,String rowText,String columnName) {
		driver = DriverFactory.getWebDriver();
		int colNum = getColumnIndexByColumnNameFromTable(tableXpath, columnName)

		int rowNum = 1
		WebElement rows = driver.findElements(By.xpath(tableXpath+"/tbody/tr"))
		if(rows.size()==0)
			rows = driver.findElements(By.xpath(tableXpath+"/table/tbody/tr"))
		for(WebElement row : rows) {
			List<WebElement> rowCells = driver.findElements(By.tagName("td"))
			if(rowCells.size() >=colNum) {
				if(rowCells.get(colNum).getText().trim().contains(rowText.trim())) {
					return rowNum
				}
			}
			rowNum++
		}
		return -1
	}


	static int getColumnIndexByColumnNameFromTable(String xpathTable, String columnName) {
		driver = DriverFactory.getWebDriver();
		WebElement cols = driver.findElements(By.xpath(xpathTable+"/thead/tr/th"))
		if(cols.size()==0)
			cols = driver.findElements(By.xpath(xpathTable+"/table/thead/tr/th"))
		int colNum=0;
		for(WebElement ele : cols) {
			String colText = ele.getText()
			if(colText !="") {
				if(colText.equals(columnName)) {
					return colNum;
				}
			}
			colNum++;
		}
		return -1;
	}

	public static List<WebElement> getRowsFromHtmlTable(String xpathTable) {
		driver = DriverFactory.getWebDriver()
		List<WebElement> rows = driver.findElements(By.xpath(xpathTable+"/tbody/tr"))
		if(rows.size()==0) {
			rows = driver.findElements(By.xpath(xpathTable+"/table/tbody/tr"))
		}

		return rows
	}

	public static List<WebElement> getColumnsFromHtmlTable(String xpathTable) {
		driver = DriverFactory.getWebDriver()
		List<WebElement> cols = driver.findElements(By.xpath(xpathTable+"/thead/tr/th"))
		if(cols.size()==0) {
			cols = driver.findElements(By.xpath(xpathTable+"/table/thead/tr/th"))
		}

		return cols
	}

	static int getColumnNumByColHeaderContainsFromHtmlTable(String xpathTable, String columnName) {
		driver = DriverFactory.getWebDriver()
		List <WebElement> rCount=getRowsFromHtmlTable(xpathTable)
		if(rCount.size() > 0) {
			int iCol = 1
			List<WebElement> cols = getColumnsFromHtmlTable(xpathTable)
			for(WebElement col : cols) {
				String colName = col.getText()
				if(colName!= null ) {
					if(colName.trim().contains(columnName)) {
						return iCol
					}
				}
				iCol++;
			}
		}
		return -1
	}
	static int getColumnNumByColHeaderEqualsFromHtmlTable(String xpathTable, String columnName) {
		driver = DriverFactory.getWebDriver()
		List <WebElement> rCount=getRowsFromHtmlTable(xpathTable)
		if(rCount.size() > 0) {
			int iCol = 1
			List<WebElement> cols = getColumnsFromHtmlTable(xpathTable)
			for(WebElement col : cols) {
				String colName = col.getText()
				if(colName!= null ) {
					if(colName.trim().equals(columnName)) {
						return iCol
					}
				}
				iCol++;
			}
		}
		return -1
	}

	static int getRowCount(String xpathTable) {

		driver = DriverFactory.getWebDriver()
		Global.driver = driver;
		List<WebElement> rows = driver.findElements(By.xpath(xpathTable+"/tbody/tr"))
		if(rows.size()==0) {
			rows = driver.findElements(By.xpath(xpathTable+"/table/tbody/tr"))
		}

		return rows.size()
	}

	static WebElement getTableCell(String xpathTable, int RowNum, int ColNum) {
		driver = DriverFactory.getWebDriver()
		Global.driver = driver;
		List<WebElement> rows = driver.findElements(By.xpath(xpathTable + "/tbody/tr"))
		if(rows.size() >= RowNum) {
			String custXpath = xpathTable+"/tbody/tr["+RowNum+"]/td["+ColNum+"]";
			return driver.findElement(By.xpath(custXpath))
		}
	}

	static long getRandomNumber() {
		Random randomNumber = new Random();

		// Generate random integers in range 0 to 999
		return randomNumber.nextInt(10000);
	}

	static long getRandomNumber(int number) {
		Random randomNumber = new Random();

		// Generate random integers in range 0 to 999
		return randomNumber.nextInt(number);
	}

	public static String getXPath(WebDriver driver,WebElement element) {
		return (String) ((JavascriptExecutor) driver).executeScript(
				"getXPath=function(node)" +
				"{" +
				"if (node.id !== '')" +
				"{" +
				"return '//' + node.tagName.toLowerCase() + '[@id=\"' + node.id + '\"]'" +
				"}" +

				"if (node === document.body)" +
				"{" +
				"return node.tagName.toLowerCase()" +
				"}" +

				"var nodeCount = 0;" +
				"var childNodes = node.parentNode.childNodes;" +

				"for (var i=0; i<childNodes.length; i++)" +
				"{" +
				"var currentNode = childNodes[i];" +

				"if (currentNode === node)" +
				"{return getXPath(node.parentNode) + '/' + node.tagName.toLowerCase() + '[' + (nodeCount+1) + ']'" +
				"}" +

				"if (currentNode.nodeType === 1 && " +
				"currentNode.tagName.toLowerCase() === node.tagName.toLowerCase())" +
				"{" +
				"nodeCount++" +
				"}" +
				"}" +
				"};" +

				"return getXPath(arguments[0]);", element);
	}

	public static  void TypeInField(WebElement element, String value) throws InterruptedException{
		String val = value;

		element.clear();

		for (int i = 0; i < val.length(); i++){
			char c = val.charAt(i);
			String s = new StringBuilder().append(c).toString();
			element.sendKeys(s);
			Thread.sleep(1000);
		}
	}

	public static void scrollByVisibleElementt(WebElement ele) {

		WebDriver driver = DriverFactory.getWebDriver()
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Launch the application
		driver.get("http://demo.guru99.com/test/guru99home/");

		//Find element by link text and store in variable "Element"
		//WebElement Element = driver.findElement(By.linkText("Linux"));

		//This will scroll the page till the element is found
		js.executeScript("arguments[0].scrollIntoView();", ele);
	}

	static String getSelectOptionFromDD(WebElement ele) {
		Select sel = new Select(ele)
		return sel.getFirstSelectedOption().getText().trim()
	}

	static String getDataFromTable(String rowHeader,String columnHeader,String rowData) {
		String xpathTable = "//*[@id='DataTables_Table_1']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = -1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, rowHeader)
		for(int i =1 ;i<=rowCount; i++) {
			if(GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim().contains(rowData)) {
				rowIndex=i
				break
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable,columnHeader)
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex).getText()
	}

	static String getDataFromTable(String xpathTable,String rowHeader,String columnHeader,String rowData) {
		//String xpathTable = "//*[@id='DataTables_Table_1']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = -1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, rowHeader)
		for(int i =1 ;i<=rowCount; i++) {
			if(GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim().contains(rowData)) {
				rowIndex=i
				break
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderEqualsFromHtmlTable(xpathTable,columnHeader)
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex).getText()
	}

	static WebElement getWebElementDataFromTable(String xpathTable,String rowHeader,String columnHeader,String rowData) {
		//String xpathTable = "//*[@id='DataTables_Table_1']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = -1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, rowHeader)
		for(int i =1 ;i<=rowCount; i++) {
			if(GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim().contains(rowData)) {
				rowIndex=i
				break
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable,columnHeader)
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex)
	}

	protected static String getXPathFromElement(RemoteWebElement element) {
		String elementDescription = element.toString();
		return elementDescription.substring(elementDescription.lastIndexOf("-> xpath: ") + 10, elementDescription.lastIndexOf("]"));
	}

	protected static TestObject fromElement(RemoteWebElement element) {
		TestObject testObject = new TestObject();
		testObject.addProperty("xpath", ConditionType.CONTAINS, getXPathFromElement(element));
		return testObject;
	}

	public static void typeCharacter( String letter) {
		Robot robot = new Robot();
		for(int i =0;i<letter.length();i++) {
			try {
				boolean upperCase = Character.isUpperCase( letter.charAt(0) );
				char chr = letter.charAt(i);
				String chrStr=chr+"";
				String variableName = "VK_" + chrStr.toUpperCase();
				Class clazz = KeyEvent.class;
				Field field = clazz.getField( variableName );
				int keyCode = field.getInt(null);

				robot.delay(1000);

				if (upperCase) robot.keyPress( KeyEvent.VK_SHIFT );

				robot.keyPress( keyCode );
				robot.keyRelease( keyCode );
				if(i>2)
					break;

				if (upperCase) robot.keyRelease( KeyEvent.VK_SHIFT );
			}
			catch(Exception e) {
				System.out.println(e);
			}
			finally {
				robot.keyRelease( KeyEvent.VK_SHIFT );
			}
		}
	}

	static void waitForLinkClickable(String text) {
		driver = DriverFactory.getWebDriver()
		//WebElement ele = driver.findElement(By.linkText(text))
		WebDriverWait wait = new WebDriverWait(driver, 30)
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText(text)))
	}
}
