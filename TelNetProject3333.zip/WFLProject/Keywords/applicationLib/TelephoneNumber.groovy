package applicationLib

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import org.openqa.selenium.By
import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.remote.RemoteWebElement

public class TelephoneNumber {

	private static WebDriver driver;
	@Keyword

	static String getPhoneNumberOfRedXFromTable() {
		String xpathTable = "//*[@id='example']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = -1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "e911")
		for(int i =1 ;i<=rowCount; i++) {
			String xpathWithoutSpan =GenericFunctions.getXPath(Global.driver,GenericFunctions.getTableCell(xpathTable, i, columnIndex))
			String xpathWithSpan = xpathWithoutSpan+"/span"
			if(Global.driver.findElement(By.xpath(xpathWithSpan)).getAttribute("class").trim().contains("telnet-text-red")) {
				rowIndex=i
				break
			}
			if(i==10) {
				i=0;
				WebUI.click(findTestObject('Object Repository/Page_Telnetapp/nextPage'))
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "Phone Number")
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex).getText()
	}

	static void setTextInZipcode(String text) {
		WebDriver driver = DriverFactory.getWebDriver()
		GenericFunctions.TypeInField(driver.findElement(By.xpath("//*[@name='zipcode']")), text)
	}

	static void scrollForCancelButton() {
		WebDriver driver = DriverFactory.getWebDriver()
		GenericFunctions.scrollByVisibleElementt(driver.findElement(By.xpath("//button[text()='Cancel']")))
	}

	@Keyword
	public static void selectNoFrome911Column() {

		//WebUI.selectOptionByLabel(findTestObject('Object Repository/MyTNs/SearchFilter_e911'), "Doesn't have data", false)
		WebUI.click(findTestObject('Object Repository/MyTNs/SearchFilter_e911'))
		WebUI.click(findTestObject('Object Repository/MyTNs/DontHaveDataOption'))
		WebUI.click(findTestObject('Object Repository/MyTNs/applyButton'))
		CommonLib.handleLoadingImange(20)




		/*WebDriver driver = DriverFactory.getWebDriver()
		 String xpathTable = "//table[@id='DataTables_Table_0']"*/


		/*//String custXpath = xpathTable+"/tbody/tr["+RowNum+"]/td["+ColNum+"]";
		 // int rowCount = GenericFunctions.getRowCount(xpathTable)
		 int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "e911")
		 // String xpathWithoutSpan =GenericFunctions.getXPath(Global.driver,GenericFunctions.getTableCell(xpathTable, 0, columnIndex))
		 String xpathWithSpan = xpathTable+"//th["+columnIndex+"]//div"
		 // int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "Phone Number")
		 driver.findElement(By.xpath(xpathWithSpan)).click()
		 driver.findElement(By.xpath("//div[contains(text(),'No')]")).click()*/
	}

	@Keyword
	static String getFirstPhoneNumberFromTable() {

		String str =null;
		try {
			String xpathTable = "//table[@id='DataTables_Table_1']"
			int rowCount = GenericFunctions.getRowCount(xpathTable)
			int rowIndex = 1
			int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "Phone Number")
			str = GenericFunctions.getTableCell(xpathTable, 1, columnIndex).getText().trim();
		}
		catch(Exception e) {
			str=null;
		}
		return str;
	}

	@Keyword
	static boolean isHeaderColumnExistOnTelephoneNumberPage(String headerName) {
		//String keyValue=null;
		boolean flag = false;
		driver = DriverFactory.getWebDriver()
		WebElement tableElement = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']"));
		List<WebElement> rowTable = tableElement.findElements(By.tagName("tr"));
		//int rowLength= rowTable.size();
		for(int i =0; i<rowTable.size();i++)
		{
			List<WebElement> dataTable=rowTable.get(i).findElements(By.tagName("th"));
			for(WebElement eleList : dataTable)
			{
				if(eleList.getText().trim().contains(headerName))
				{
					println(eleList.getText().trim())
					//println(eleList.getText().trim())


					flag = true;
					break;


				}
				if(flag)
					break;
			}
			if(flag)
				break;
		}


		return flag;

	}
}
