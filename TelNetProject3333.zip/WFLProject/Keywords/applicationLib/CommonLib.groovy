package applicationLib

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject


import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.firefox.FirefoxOptions
import org.openqa.selenium.firefox.FirefoxProfile
import org.openqa.selenium.remote.server.DefaultDriverFactory
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.WebDriverWait
import org.openqa.selenium.By

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.driver.DriverType
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable // as GlobalVariable

//import internal.GlobalVariable

public class CommonLib {

	private static WebDriver driver;
	static File folder;
	@Keyword
	static def Login() {

		//FirefoxProfile profile = new FirefoxProfile();
		//WebDriver driver = DriverFactory.getWebDriver();

		WebUI.openBrowser(Global.url)
		WebUI.maximizeWindow();
		WebUI.waitForElementPresent(findTestObject('Object Repository/CommonObjects/Username'), 20)
		WebUI.setText(findTestObject('Object Repository/CommonObjects/Username'),Global.Username)

		WebUI.setText(findTestObject('Object Repository/CommonObjects/Password'),Global.Password)
		//println (Global.Password)
		WebUI.click(findTestObject('Object Repository/CommonObjects/Login'))
		driver = DriverFactory.getWebDriver()
		Global.driver = driver;

	}
	@Keyword
	static def LoginForImpersonate() {

		//FirefoxProfile profile = new FirefoxProfile();
		//WebDriver driver = DriverFactory.getWebDriver();

		WebUI.openBrowser(Global.url)
		WebUI.maximizeWindow();
		WebUI.waitForElementPresent(findTestObject('Object Repository/CommonObjects/Username'), 20)
		WebUI.setText(findTestObject('Object Repository/CommonObjects/Username'),Global.UsernameForImpersonate)

		WebUI.setText(findTestObject('Object Repository/CommonObjects/Password'),Global.PasswordForImpersonate)
		//println (Global.Password)
		WebUI.click(findTestObject('Object Repository/CommonObjects/Login'))
		driver = DriverFactory.getWebDriver()
		Global.driver = driver;

	}

	@Keyword
	static def loginAsCustomerNonAdmin() {

		//FirefoxProfile profile = new FirefoxProfile();
		//WebDriver driver = DriverFactory.getWebDriver();

		WebUI.openBrowser(Global.url)
		WebUI.maximizeWindow();
		WebUI.waitForElementPresent(findTestObject('Object Repository/CommonObjects/Username'), 20)
		WebUI.setText(findTestObject('Object Repository/CommonObjects/Username'),Global.customeNonAdminUser)

		WebUI.setText(findTestObject('Object Repository/CommonObjects/Password'),Global.Password)
		//println (Global.Password)
		WebUI.click(findTestObject('Object Repository/CommonObjects/Login'))
		driver = DriverFactory.getWebDriver()
		Global.driver = driver;

	}

	@Keyword
	static def logout() {

		//FirefoxProfile profile = new FirefoxProfile();
		//WebDriver driver = DriverFactory.getWebDriver();


		WebUI.click(findTestObject('CommonObjects/LoggedInImage'))
		CommonLib.handleLoadingImange(10)
		WebUI.click(findTestObject('CommonObjects/Logout'))
		CommonLib.handleLoadingImange(60)
		WebUI.verifyTextPresent("Logout", false)


	}

	public static boolean isFileDownloaded() {
		boolean flag = false;
		// File dir = new File(downloadPath);

		File[] fileArray=folder.listFiles();

		if(fileArray.length>0)
		{
			for(File file : folder.listFiles())
			{
				if(file.length()>0)
				{
					file.delete();
					flag=true;
				}

			}

			folder.delete();
		}



		return flag;
	}

	@Keyword
	static def LoginForExport() {

		folder = new File(UUID.randomUUID().toString());

		folder.mkdir();
		//FirefoxProfile profile = new FirefoxProfile();
		// driver = DriverFactory.getWebDriver();
		WebUIDriverType executeDriver = DriverFactory.getExecutedBrowser()

		if(WebUIDriverType.FIREFOX_DRIVER.equals(executeDriver))
		{
			System.setProperty("webdriver.gecko.driver", "Drivers\\geckodriver.exe")
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.dir", folder.getAbsolutePath());
			profile.setPreference("browser.download.folderList", 2);
			//Set Preference to not show file download confirmation dialogue using MIME types Of different file extension types.
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk","text/csv");

			profile.setPreference( "browser.download.manager.showWhenStarting", false );
			profile.setPreference("pdfjs.disabled",true);
			FirefoxOptions options = new FirefoxOptions();
			options.setProfile(profile);
			driver = new FirefoxDriver(options);

		}
		else if(WebUIDriverType.CHROME_DRIVER.equals(executeDriver))
		{
			System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
			ChromeOptions options= new ChromeOptions();
			Map<String ,Object> prefers = new HashMap<String , Object>();

			prefers.put("profile.default_content_setting.popups", 0);
			prefers.put("download.default_directory", folder.getAbsolutePath());

			options.setExperimentalOption("prefs", prefers);


			//	DesiredCapabilities cap = DesiredCapabilities.chrome();

			//cap.setCapability(ChromeOptions.CAPABILITY, options);
			driver =new  ChromeDriver(options);
		}
		driver.get(Global.url)
		driver.manage().window().maximize()
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("Username")));

		driver.findElement(By.id("Username")).sendKeys(Global.Username)
		driver.findElement(By.id("Password")).sendKeys(Global.Password)
		//WebUI.setText(findTestObject('Object Repository/CommonObjects/Username'),Global.Username)

		//	WebUI.setText(findTestObject('Object Repository/CommonObjects/Password'),Global.Password)
		//println (Global.Password)
		driver.findElement(By.xpath("//button[@type='submit']")).click()
		//	WebUI.click(findTestObject('Object Repository/CommonObjects/Login'))

		DriverFactory.changeWebDriver(driver);



	}

	@Keyword
	static def clickOnEditButtonOfTrunkGroupName(String trunkGroupName) {
		//println(trunkGroupName)
		boolean flag = false;
		driver = DriverFactory.getWebDriver()
		WebElement tableElement = driver.findElement(By.xpath("//table[@id='example']/tbody"));
		List<WebElement> rowTable = tableElement.findElements(By.tagName("tr"));
		//int rowLength= rowTable.size();
		for(int i =0; i<rowTable.size();i++)
		{
			List<WebElement> dataTable=rowTable.get(i).findElements(By.tagName("td"));
			for(WebElement eleList : dataTable)
			{
				if(eleList.getText().trim().equals(trunkGroupName))
				{
					for(int j =0;j<dataTable.size();j++)
					{
						//System.out.println(dataTable.get(dataTable.size()-2).getText());
						String customXpath = "//table[@id='example']/tbody/tr["+(i+1)+"]/td["+dataTable.size()+"]/a/span/i";
						//println(customXpath)
						driver.findElement(By.xpath(customXpath)).click();
						flag = true;
						break;
					}

				}
				if(flag)
					break;
			}
			if(flag)
				break;
		}

	}


	static  String getDataFromGeneralSection(String key)
	{
		String keyValue=null;
		boolean flag = false;
		driver = DriverFactory.getWebDriver()
		WebElement tableElement = driver.findElement(By.xpath("//div[@class='row']//div[1]//div[1]//table[1]/tbody"));
		List<WebElement> rowTable = tableElement.findElements(By.tagName("tr"));
		//int rowLength= rowTable.size();
		for(int i =0; i<rowTable.size();i++)
		{
			List<WebElement> dataTable=rowTable.get(i).findElements(By.tagName("td"));
			for(WebElement eleList : dataTable)
			{
				if(eleList.getText().equals("Status"))
				{

					//System.out.println(dataTable.get(dataTable.size()-2).getText());
					String customXpath = "//div[@class='row']//div[1]//div[1]//table[1]/tbody/tr["+(i+1)+"]/td[2]";

					keyValue=driver.findElement(By.xpath(customXpath)).getText()
					flag = true;
					break;


				}
				if(flag)
					break;
			}
			if(flag)
				break;
		}


		return keyValue;
	}

	static boolean isHeaderColumnExist(String headerName)
	{
		//String keyValue=null;
		boolean flag = false;
		driver = DriverFactory.getWebDriver()
		WebElement tableElement = driver.findElement(By.xpath("//table[@id='example']"));
		List<WebElement> rowTable = tableElement.findElements(By.tagName("tr"));
		//int rowLength= rowTable.size();
		for(int i =0; i<rowTable.size();i++)
		{
			List<WebElement> dataTable=rowTable.get(i).findElements(By.tagName("th"));
			for(WebElement eleList : dataTable)
			{
				if(eleList.getText().trim().contains(headerName))
				{
					println(eleList.getText().trim())
					//println(eleList.getText().trim())


					flag = true;
					break;


				}
				if(flag)
					break;
			}
			if(flag)
				break;
		}


		return flag;

	}

	@Keyword
	static void handleLoadingImange(int maxTimeInSeconds)
	{
		driver = DriverFactory.getWebDriver()
		try
		{

			Thread.sleep(5000);


			WebElement sImgOne = driver.findElement(By.xpath("//*[@class='img-fluid text-center']"));

			//WebUI.waitForElementVisible(GenericFunctions.fromElement(sImgOne), 60)

			GenericFunctions.highlightElement(driver, sImgOne)

			//var sImgOne1 = GenericFunctions.CreateObject(Global.GlobalBW, "HtmlImage|id=spinningManImg");
			int i = 0;

			while (sImgOne != null)
			{

				Thread.sleep(2000);

				sImgOne = driver.findElement(By.xpath("//*[@class='img-fluid text-center']"));
				i++;
				print(i)

				if (i > (maxTimeInSeconds / 2))
					break;


			}


		}
		catch (Exception e)
		{
			//e.printStackTrace()
		}

	}



}
