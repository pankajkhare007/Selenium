package applicationLib

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import helper.GenericFunctions
import internal.GlobalVariable
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.support.ui.Select
import org.openqa.selenium.By
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import helper.Global
public class E911 {

	static WebDriver driver;
	@Keyword
	static String getPhoneNumberFromCreateNewRecordTable() {
		driver = DriverFactory.getWebDriver()
		return driver.findElement(By.xpath("//table[@id='e911Table']/tbody/tr[1]/td[2]")).getText()
	}

	@Keyword
	static String selectPhoneNumberForCreateNewRecord() {
		driver = DriverFactory.getWebDriver()
		driver.findElement(By.xpath("//table[@id='e911Table']/tbody/tr[1]/td[1]/label[1]")).click()
		return driver.findElement(By.xpath("//*[@id='e911Table']/tbody/tr[1]/td[2]")).getText().trim()
	}

	@Keyword
	static TestObject setZipcodeOnCreateNewRecord(String zipcode) {
		//GenericFunctions.fromElement(DriverFactory.getWebDriver().findElement(By.xpath("")))

		WebUiCommonHelper.findWebElement(findTestObject('Object Repository/CreateNewRecord/zipcode_CreateNewRecord'), 10).sendKeys(zipcode)
	}

	@Keyword
	static String getPhoneNumberWithoutRecordFromTable() {
		String xpathTable = "//*[@id='DataTables_Table_0']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = 1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "Customer Name")
		for(int i =1 ;i<=rowCount; i++) {
			String str = GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim();
			println(str)
			if(GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim().isEmpty()) {
				rowIndex=i
				break
			}

			if(i==10) {
				i=0;
				WebUI.click(findTestObject('Object Repository/Page_Telnetapp/nextPage'))
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable,"Phone Number")
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex).getText()
	}

	@Keyword
	static String getPhoneNumberWithRecordFromTable() {
		String xpathTable = "//*[@id='DataTables_Table_0']"
		int rowCount = GenericFunctions.getRowCount(xpathTable)
		int rowIndex = 1
		int columnIndex=GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable, "Customer Name")
		for(int i =1 ;i<=rowCount; i++) {
			String str = GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim();
			println(str)
			if(!GenericFunctions.getTableCell(xpathTable, i, columnIndex).getText().trim().isEmpty()) {
				rowIndex=i
				break
			}

			if(i==10) {
				i=0;
				WebUI.click(findTestObject('Object Repository/Page_Telnetapp/nextPage'))
			}
		}
		int trunkGroupIndex = GenericFunctions.getColumnNumByColHeaderContainsFromHtmlTable(xpathTable,"Phone Number")
		return GenericFunctions.getTableCell(xpathTable, rowIndex, trunkGroupIndex).getText()
	}

	@Keyword
	public static void searchTelephoneNumberOnCreateNewRecord(String text) {
		driver = DriverFactory.getWebDriver()

		List<WebElement> eleList = driver.findElements(By.xpath("//input[@type='search']"))
		eleList.get(1).click()
		eleList.get(1).sendKeys(text)
	}

	@Keyword
	public static void selectPrefix(String labelName) {

		//WebUI.selectOptionByLabel(findTestObject('Object Repository/MyTNs/SearchFilter_e911'), "Doesn't have data", false)
		WebUI.click(findTestObject('Object Repository/Page_Telnetapp/prefixDD'))
		String xpathCust="//span[contains(text(),'"+labelName+"')]"
		Global.driver.findElement(By.xpath(xpathCust)).click()


	}
}
