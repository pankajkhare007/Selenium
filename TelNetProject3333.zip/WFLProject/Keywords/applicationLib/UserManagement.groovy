package applicationLib

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.junit.After
import org.openqa.selenium.By
import org.openqa.selenium.remote.server.DefaultDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory
import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable

public class UserManagement {

	private static WebDriver driver;
	@Keyword
	static def verifySearchFilterSection() {
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/NameSearchEditBox'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/EmailSearchEditBox'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/AccountSearchEditBox'), 1)
	}

	@Keyword
	static boolean isHeaderColumnExist(String headerName) {
		//String keyValue=null;
		boolean flag = false;
		driver = DriverFactory.getWebDriver()
		WebElement tableElement = driver.findElement(By.xpath("//table[@class='table mt-2 table-bordered data-table dataTable no-footer']"));
		List<WebElement> rowTable = tableElement.findElements(By.tagName("tr"));
		//int rowLength= rowTable.size();
		for(int i =0; i<rowTable.size();i++)
		{
			List<WebElement> dataTable=rowTable.get(i).findElements(By.tagName("th"));
			for(WebElement eleList : dataTable)
			{
				if(eleList.getText().trim().contains(headerName))
				{
					println(eleList.getText().trim())
					//println(eleList.getText().trim())


					flag = true;
					break;


				}
				if(flag)
					break;
			}
			if(flag)
				break;
		}


		return flag;

	}

	@Keyword
	static def verifyUserManagementTableColumns()
	{
		isHeaderColumnExist("Account Name")
		isHeaderColumnExist("Name")
		isHeaderColumnExist("Email")
		isHeaderColumnExist("Role")
		isHeaderColumnExist("Status")
		isHeaderColumnExist("Manage")

	}

	@Keyword
	static def searchUserFromTable(String userEmailID)
	{
		WebUI.setText(findTestObject('Object Repository/CommonObjects/UserManagement/EmailSearchEditBox'), userEmailID)
		WebUI.click(findTestObject('Object Repository/MyTNs/applyButton'))
		CommonLib.handleLoadingImange(30)


	}

	static def getDataFromUserTable()
	{
		String sTable="//table[@class='table mt-2 table-bordered data-table dataTable no-footer']"
		Global.sAccountName_CustomerAdmin=GenericFunctions.getDataFromTable(sTable, "Email", "Account Name", Global.Username)
		Global.sName_CustomerAdmin=GenericFunctions.getDataFromTable(sTable, "Email", "Name", Global.Username)
		Global.sRole_CustomerAdmin=GenericFunctions.getDataFromTable(sTable, "Email", "Role", Global.Username)
		Global.sStatus_CustomerAdmin=GenericFunctions.getDataFromTable(sTable, "Email", "Status", Global.Username)

	}
	static def clickOnEditButton()
	{
		String sTable="//table[@class='table mt-2 table-bordered data-table dataTable no-footer']"
		WebElement ele = GenericFunctions.getWebElementDataFromTable(sTable, "Email", "Manage", Global.Username)
		ele.findElement(By.linkText("Edit")).click()
		CommonLib.handleLoadingImange(30)
	}

	static def verifyBasicInformationSectionOfUser()
	{
		WebUI.verifyEqual(getValueFromLabel("Email"), Global.Username)
		String sFullName=Global.sName_CustomerAdmin
		String[] arr=sFullName.split(' ')
		String sFirstName=arr[0].trim()
		String sLastName=arr[1].trim()
		WebUI.verifyEqual(getValueFromLabel("First Name"), sFirstName)
		WebUI.verifyEqual(getValueFromLabel("Last Name"), sLastName)
	}

	static String getValueFromLabel(String lableName)
	{
		String custXpath="//label[contains(text(),'"+lableName+"')]/parent::*/div/input";
		driver = DriverFactory.getWebDriver()


		return driver.findElement(By.xpath(custXpath)).getAttribute("value")
	}

	static def verifyAccountSettingSectionOfUser()
	{
		WebElement ele =Global.driver.findElement(By.xpath("//input[@id='mat-input-0']"))
		GenericFunctions.highlightElement(Global.driver, ele)
		String sDefaultAccount=ele.getText()
		ele.click()
		CommonLib.handleLoadingImange(10)
		List<WebElement> accountlist=Global.driver.findElements(By.xpath("//mat-option"))
		int numberOfAccount=accountlist.size()
		if(numberOfAccount==2)
		{
			WebUI.verifyEqual(accountlist.get(1).getText().trim(), Global.sAccountName_CustomerAdmin)
		}

		String defaultUserRole=Global.driver.findElement(By.xpath("//mat-select[@id='mat-select-0']")).getText()
		WebUI.verifyEqual(defaultUserRole, Global.sRole_CustomerAdmin)
		//String sDefaultAccount=WebUI.getAttribute(findTestObject('Object Repository/CommonObjects/UserManagement/Account_AccountSettings'), "value")
	}

	static def verifyAddMoreFunctionality_AccountSetting(String accountName,String role)
	{
		// select Account
		List<WebElement> textBoxList=Global.driver.findElements(By.xpath("//*[@class='mat-form-field-infix']/input"))
		int numberOfAccountTextBox=textBoxList.size()
		if(numberOfAccountTextBox==1)
		{
			WebUI.click(findTestObject('Object Repository/CommonObjects/UserManagement/AddMoreButton'))
			CommonLib.handleLoadingImange(10)
			textBoxList=Global.driver.findElements(By.xpath("//*[@class='mat-form-field-infix']/input"))
			numberOfAccountTextBox=textBoxList.size()
			WebUI.verifyEqual(numberOfAccountTextBox,2)
			textBoxList.get(1).click()

			List<WebElement> accountlist=Global.driver.findElements(By.xpath("//span[contains(@class,'mat-option-text')]"))
			for(WebElement ele : accountlist)
			{
				print(ele.getText())
				if(ele.getText().trim().equals(accountName))
				{
					ele.click()
					CommonLib.handleLoadingImange(10)
					break;
				}

			}


		}

		List<WebElement> textBoxListRole=Global.driver.findElements(By.xpath("//mat-select[contains(@id,'mat-select')]"))
		int numberOfRoleTextBox=textBoxListRole.size()
		if(numberOfRoleTextBox==2)
		{
			textBoxListRole.get(1).click()
			List<WebElement> rolelist=Global.driver.findElements(By.xpath("//span[contains(@class,'mat-option-text')]"))
			for(WebElement ele : rolelist)
			{
				print(ele.getText())
				if(ele.getText().trim().equals(role))
				{
					ele.click()
					break;
				}
			}
		}

		WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))
		CommonLib.handleLoadingImange(10)

		WebUI.click(findTestObject('Object Repository/CommonObjects/UserManagement/SaveBtn_Popup'))
		CommonLib.handleLoadingImange(10)
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/SuccessMsg'), 1)

	}
	static def removeLastRoleFromUser()
	{
		List<WebElement> redXList=Global.driver.findElements(By.xpath("//a[@class='text-danger fs18 ng-star-inserted']"))
		int numberOfRedList=redXList.size()
		redXList.get(numberOfRedList-1).click()
		WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))
		CommonLib.handleLoadingImange(10)

		WebUI.click(findTestObject('Object Repository/CommonObjects/UserManagement/SaveBtn_Popup'))
		CommonLib.handleLoadingImange(10)
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/SuccessMsg'), 1)

	}

	static String getAccountNameFromAccountSetting()
	{
		Global.sAccountName_CustomerAdmin =Global.driver.findElement(By.xpath("//input[contains(@id,'mat-input')]")).getAttribute("value")

		return Global.sAccountName_CustomerAdmin

	}

	static def loginAsImpersonate(String userID)
	{

		WebUI.click(findTestObject('Object Repository/Impersonate/impersonateMenu'))


		WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/searchTextBox'), 10)

		CommonLib.handleLoadingImange(60)

		WebUI.setText(findTestObject('Object Repository/Impersonate/searchTextBox'),userID)

		WebUI.click(findTestObject('Object Repository/Impersonate/searchButton'))

		CommonLib.handleLoadingImange(20)

		//WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)

		WebUI.click(findTestObject('Object Repository/Impersonate/impersonateLink'))

		WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'), 10)

		CommonLib.handleLoadingImange(60)

		WebUI.click(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'))

		WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/redBar'), 10)
		CommonLib.handleLoadingImange(60)


	}

	static def addAccountAndRole_AccountSetting(String accountName,String role)
	{
		Global.driver.findElement(By.xpath("//*[@class='mat-form-field-infix']/input")).click()
		List<WebElement> accountlist=Global.driver.findElements(By.xpath("//span[contains(@class,'mat-option-text')]"))
		for(WebElement ele : accountlist)
		{
			print(ele.getText())
			if(ele.getText().trim().equals(accountName))
			{
				ele.click()
				CommonLib.handleLoadingImange(10)
				break;
			}

		}

		Global.driver.findElement(By.xpath("//mat-select[contains(@id,'mat-select')]")).click()
		List<WebElement> rolelist=Global.driver.findElements(By.xpath("//span[contains(@class,'mat-option-text')]"))
		for(WebElement ele : rolelist)
		{
			print(ele.getText())
			if(ele.getText().trim().equals(role))
			{
				ele.click()
				break;
			}
		}
		WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))
		CommonLib.handleLoadingImange(10)

		WebUI.click(findTestObject('Object Repository/CommonObjects/UserManagement/SaveBtn_Popup'))
		CommonLib.handleLoadingImange(10)
		WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagement/SuccessMsg'), 1)


	}

	static def clickOnAccountNamesDD()
	{
		Global.driver.findElement(By.xpath("//mat-select[@name='acountNames']")).click()
		CommonLib.handleLoadingImange(2)
	}
	static def verifyAccountNamesOnHomePage(String role)
	{

		boolean flag =false;
		boolean expectedFlag=true
		List<WebElement> rolelist=Global.driver.findElements(By.xpath("//span[contains(@class,'mat-option-text')]"))
		for(WebElement ele : rolelist)
		{
			print(ele.getText())
			if(ele.getText().trim().equals(role))
			{
				flag=true
				break;
			}
		}
		WebUI.verifyEqual(flag, expectedFlag)
	}
}
