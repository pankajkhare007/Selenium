import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import applicationLib.CommonLib
import helper.Global as Global
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'applicationLib.CommonLib.LoginForImpersonate'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateMenu'))


WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/searchTextBox'), 10)

CommonLib.handleLoadingImange(60)

WebUI.setText(findTestObject('Object Repository/Impersonate/searchTextBox'), Global.impesonateUser)

WebUI.click(findTestObject('Object Repository/Impersonate/searchButton'))

//WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)
WebUI.verifyElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateLink'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'), 10)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/redBar'), 10)
CommonLib.handleLoadingImange(60)

String expectedResult = 'You are impersonating as ' + Global.impesonateUser

String actualResult = WebUI.getText(findTestObject('Object Repository/Impersonate/redBar'))

WebUI.verifyEqual(expectedResult, actualResult)

WebUI.click(findTestObject('CommonObjects/LoggedInImage'))

WebUI.click(findTestObject('CommonObjects/Logout'))

WebUI.verifyTextPresent('Logout', false)

WebUI.closeBrowser()

