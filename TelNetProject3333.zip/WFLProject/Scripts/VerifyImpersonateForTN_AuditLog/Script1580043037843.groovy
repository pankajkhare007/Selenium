import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.E911
import helper.Global as Global
import internal.GlobalVariable as GlobalVariable
import applicationLib.TelephoneNumber as TelephoneNumber
import helper.GenericFunctions as GenericFunctions

CustomKeywords.'applicationLib.CommonLib.LoginForImpersonate'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

E911.selectPrefix("W")

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateMenu'))

CommonLib.handleLoadingImange(30)

WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/searchTextBox'), 10)

WebUI.setText(findTestObject('Object Repository/Impersonate/searchTextBox'), Global.impesonateUser)

WebUI.click(findTestObject('Object Repository/Impersonate/searchButton'))

//WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)
WebUI.verifyElementPresent(findTestObject('Object Repository/Impersonate/table_Impersonate'), 10)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateLink'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'), 10)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Impersonate/impersonateButton_ConfirmationPopup'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Impersonate/redBar'), 10)

CommonLib.handleLoadingImange(60)

String expectedResult = 'You are impersonating as ' + Global.impesonateUser

String actualResult = WebUI.getText(findTestObject('Object Repository/Impersonate/redBar'))

WebUI.verifyEqual(expectedResult, actualResult)

WebUI.click(findTestObject('Services/Services'))


GenericFunctions.waitForLinkClickable("Telephone Numbers (TN)")

CommonLib.handleLoadingImange(30)
//CommonLib.handleLoadingImange(30)
//WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'), 30)

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'))
GenericFunctions.clickOnLinkText("Telephone Numbers (TN)")



//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(30)

TelephoneNumber.selectNoFrome911Column()

String sRedXTN = TelephoneNumber.getFirstPhoneNumberFromTable()

//println(sRedXTN)
GenericFunctions.clickOnLinkText(sRedXTN)

CommonLib.handleLoadingImange(30)



String customerName = 'Customer' + GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/customerName'), customerName)

String houseNumber = "4546644344"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/houseNumber'), houseNumber)

/*String homeNumberSuffix = GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/houseNumberSuffix'), homeNumberSuffix)*/


WebUI.click(findTestObject('Object Repository/Page_Telnetapp/E911Edit'))

CommonLib.handleLoadingImange(10)

String city ="Troy"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/city'), city)

//WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/prefixDD'), 'W', false)
E911.selectPrefix("W")

WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/postFixDD'), 'N/A', false)

//WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/stateDD'), 'CA', false)

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/stateDD'), 'MI')

String location = 'Loc' + GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/location'), location)

String streetName = "Long Lake Rd"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/streetName'), streetName)

String zipcode = "48098"

TelephoneNumber.setTextInZipcode(zipcode)

//WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/zipcode'), zipcode)
WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton'))

CommonLib.handleLoadingImange(30)

WebUI.click(findTestObject('Object Repository/Impersonate/closeRexBar'))

CommonLib.handleLoadingImange(30)


WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

//CommonLib.handleLoadingImange(30)


TelephoneNumber.selectNoFrome911Column()

String firstRecord = TelephoneNumber.getFirstPhoneNumberFromTable()

WebUI.verifyNotEqual(firstRecord,sRedXTN)

WebUI.click(findTestObject('CommonObjects/LoggedInImage'))

WebUI.click(findTestObject('CommonObjects/Logout'))

WebUI.verifyTextPresent('Logout', false)

WebUI.closeBrowser()

