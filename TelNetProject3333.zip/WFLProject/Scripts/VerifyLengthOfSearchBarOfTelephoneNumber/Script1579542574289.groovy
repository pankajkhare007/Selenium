import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import applicationLib.CommonLib as CommonLib
import applicationLib.TollFreeNumbers
import helper.GenericFunctions
import helper.Global


CustomKeywords.'applicationLib.CommonLib.Login'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

WebUI.verifyTextPresent('Welcome to your SIP Portal', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Object Repository/Services/Services'))

//Thread.sleep(2000)
//WebUI.waitForPageLoad(30)
GenericFunctions.waitForLinkClickable("Toll Free Numbers (TFN)")

GenericFunctions.clickOnLinkText("Toll Free Numbers (TFN)")

//Thread.sleep(2000)

GenericFunctions.waitForLinkClickable("Search/Reserve TFN")

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/reserveNewTFN'))

GenericFunctions.clickOnLinkText("Search/Reserve TFN")

int actualLength=Integer.parseInt(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/searchBlock1'), "maxlength"))

WebUI.verifyEqual(actualLength, 3)

actualLength=Integer.parseInt(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/searchBlock2'), "maxlength"))

WebUI.verifyEqual(actualLength, 3)

actualLength=Integer.parseInt(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/searchBlock3'), "maxlength"))

WebUI.verifyEqual(actualLength, 4)



WebUI.takeScreenshot()

WebUI.click(findTestObject('CommonObjects/LoggedInImage'))

WebUI.click(findTestObject('CommonObjects/Logout'))

WebUI.verifyTextPresent('Logout', false)

WebUI.closeBrowser()
