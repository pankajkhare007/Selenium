import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import applicationLib.CommonLib as CommonLib
import applicationLib.TollFreeNumbers
import helper.GenericFunctions
import helper.Global

CustomKeywords.'applicationLib.CommonLib.LoginForExport'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

WebUI.verifyTextPresent('Welcome to your SIP Portal', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Object Repository/Services/Services'))
GenericFunctions.waitForLinkClickable("Toll Free Numbers (TFN)")
//WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/tollFreeNumber'), 5)

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/tollFreeNumber'))

GenericFunctions.clickOnLinkText("Toll Free Numbers (TFN)")

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/myTFN'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/phoneNoTable'), 20)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Services/exportButton'))

Thread.sleep(3000)

boolean flag = CommonLib.isFileDownloaded()

WebUI.verifyEqual(flag, true)


WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Phone Number'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('In Service Date'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Trunk Group'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Ring-to-Number'), true)

WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Status'), true)

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'), Global.tollFreeNumber)
GenericFunctions.clickOnLinkText(Global.tollFreeNumber)

CommonLib.handleLoadingImange(60)
//WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/assosciatedTrunkGroupNameDD'), Global.trunkGroupName, false)
WebUI.selectOptionByIndex(findTestObject('Object Repository/Page_Telnetapp/assosciatedTrunkGroupNameDD'), TollFreeNumbers.getRandonNumberOneToNine())

String selectedOption=TollFreeNumbers.getOptionFromAssociatedTrunkGroupDD()

String ringToNumber="456443"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/ringToNumber'), ringToNumber)



WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/saveButton_e911_ConfirmationPopup'), 20)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton_e911_ConfirmationPopup'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/cancelBtn'), 20)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/cancelBtn'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/myTFN'), 20)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/myTFN'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/phoneNoTable'), 20)

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'), Global.tollFreeNumber)

String actualTG = TollFreeNumbers.getTrunkGroupAssciatedWithPhoneNumberFromTable(Global.tollFreeNumber)


WebUI.verifyEqual(actualTG, selectedOption)


WebUI.verifyEqual(GenericFunctions.getDataFromTable("Phone Number", "Ring-to-Number", Global.tollFreeNumber), ringToNumber)

WebUI.takeScreenshot()

WebUI.click(findTestObject('CommonObjects/LoggedInImage'))

WebUI.click(findTestObject('CommonObjects/Logout'))

WebUI.verifyTextPresent('Logout', false)

WebUI.closeBrowser()
