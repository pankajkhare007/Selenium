import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.SIPTrunking
import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'applicationLib.CommonLib.Login'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)
WebUI.verifyTextPresent("Welcome to your SIP Portal", false)
WebUI.takeScreenshot()

WebUI.click(findTestObject('Services/Services'))

WebUI.click(findTestObject('Services/a_SIP Trunking'))

WebUI.waitForElementPresent(findTestObject('Page_Telnetapp/searchTextBox'), 20)
//CommonLib.handleLoadingImange(30)


WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Trunk Group Name'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Trunk Group ID'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Qty of Call Paths'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('# of Telephone Numbers'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Primary Routing'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Primary'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Secondary'), true)
WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Status'), true)


WebUI.verifyElementPresent(findTestObject('Page_Telnetapp/searchTextBox1'), 5)

Global.trunkGroupName=SIPTrunking.getFirstTrunkGroupNameFromTable();
WebUI.setText(findTestObject('Page_Telnetapp/searchTextBox1'), Global.trunkGroupName)



//WebUI.click(findTestObject('Services/td_Inference-SFLF450478'))
GenericFunctions.clickOnLinkText(Global.trunkGroupName)

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/cancelBtn_ManageSIPTrunks'), 30)

CommonLib.handleLoadingImange(30)

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/trunkGroupNameTextBox_Inference'), 5)
WebUI.takeScreenshot()
CommonLib.logout()

WebUI.closeBrowser()




