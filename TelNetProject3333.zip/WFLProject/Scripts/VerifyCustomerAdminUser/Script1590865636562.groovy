import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable


import applicationLib.CommonLib
import applicationLib.E911
import applicationLib.UserManagement
import helper.Global
import helper.GenericFunctions

CustomKeywords.'applicationLib.CommonLib.Login'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

//WebUI.verifyElementNotPresent(findTestObject('Object Repository/Impersonate/impersonateMenu'), 0)
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/AuditLogs'), 0)
WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/SettingMenu'), 0)
WebUI.verifyElementNotVisible(findTestObject('Object Repository/Impersonate/impersonateMenu'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(60)
E911.getPhoneNumberWithRecordFromTable()
Global.phoneNumberFore911 =E911.getPhoneNumberWithRecordFromTable()


WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'),Global.phoneNumberFore911)

WebUI.click(findTestObject('Object Repository/MyTNs/applyButton'))
CommonLib.handleLoadingImange(30)

GenericFunctions.waitForLinkClickable(Global.phoneNumberFore911)
GenericFunctions.clickOnLinkText(Global.phoneNumberFore911)

//WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/customerName'), 20)

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/customerName'), 20)

WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/E911_Save_Popup'), 1)

WebUI.click(findTestObject('Object Repository/CommonObjects/E911_Cancel_Popup'))
CommonLib.handleLoadingImange(10)

WebUI.click(findTestObject('Object Repository/CommonObjects/SettingMenu'))

WebUI.verifyElementPresent(findTestObject('Object Repository/CommonObjects/UserManagementMenu'), 1)
WebUI.click(findTestObject('Object Repository/CommonObjects/UserManagementMenu'))
CommonLib.handleLoadingImange(60)
UserManagement.verifySearchFilterSection()
UserManagement.verifyUserManagementTableColumns()
WebUI.takeScreenshot();
UserManagement.searchUserFromTable(Global.Username)
UserManagement.clickOnEditButton()
WebUI.verifyElementNotPresent(findTestObject('CommonObjects/UserManagement/AdminRoleSwitchOff'), 0)

CommonLib.logout()