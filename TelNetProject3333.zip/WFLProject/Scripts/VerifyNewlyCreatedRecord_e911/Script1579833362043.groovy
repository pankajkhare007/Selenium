import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.E911
import applicationLib.TelephoneNumber
import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable as GlobalVariable

//E911.searchTelephoneNumberOnCreateNewRecord(phoneNum)
CustomKeywords.'applicationLib.CommonLib.Login'()


WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'), 30)

//WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'), 20)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'))

WebUI.waitForElementPresent(findTestObject('CreateNewRecord/nextBtn_e911'), 20)

//E911.searchTelephoneNumberOnCreateNewRecord("444433")
CommonLib.handleLoadingImange(30)


String phoneNum = E911.selectPhoneNumberForCreateNewRecord()

WebUI.click(findTestObject('CreateNewRecord/nextBtn_e911'))




String customerName = "Customer"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/customerName_CreateNewRecord'), customerName)

String houseNumber = "1000"

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/houseNumber_CreateNewRecord'), houseNumber)

String homeNumberSuffix = GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/houseNumSuffix_CreateNewRecord'), homeNumberSuffix)
WebUI.selectOptionByLabel(findTestObject('Object Repository/CreateNewRecord/prefix_CreateNewRecord'), "W", false)
//E911.selectVisibleByTextFromDD(findTestObject('Object Repository/CreateNewRecord/prefix_CreateNewRecord'), "SE")

WebUI.selectOptionByLabel(findTestObject('Object Repository/CreateNewRecord/postFix_CreateNewRecord'), "N/A", false)


//WebUI.selectOptionByLabel(findTestObject('Object Repository/CreateNewRecord/streetSuffix_CreateNewRecord'), "BGS", false)

String state = "MI"

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/state_CreateNewRecord'), state)

String location = "Loc"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/location_CreateNewRecord'), location)


String streetName = "Long Lake Rd"

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/streetName_CreateNewRecord'), streetName)

String city = "cali"+ GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/CreateNewRecord/city_CreateNewRecord'), "Troy")

String zipcode = "48098"

E911.setZipcodeOnCreateNewRecord(zipcode)

WebUI.click(findTestObject('Object Repository/CreateNewRecord/nextBtn1_CreateNewRecord'))

WebUI.waitForElementPresent(findTestObject('Object Repository/CreateNewRecord/finishBtn_CreateNewRecord'), 10)

CommonLib.handleLoadingImange(10)

WebUI.click(findTestObject('Object Repository/CreateNewRecord/finishBtn_CreateNewRecord'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'), 30)

CommonLib.handleLoadingImange(10)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'), 30)

CommonLib.handleLoadingImange(10)
/*
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/createNewRecordBtn'))

WebUI.waitForElementPresent(findTestObject('CreateNewRecord/nextBtn_e911'), 20)

//WebUI.setText(findTestObject('Object Repository/CreateNewRecord/search_CreateNewRecord'), phoneNum)
E911.searchTelephoneNumberOnCreateNewRecord(phoneNum)
String actualResult = WebUI.getText(findTestObject('Object Repository/CreateNewRecord/lableNoRecordsFound')).trim()

WebUI.verifyEqual(actualResult, "No matching records found")*/
CommonLib.logout()
WebUI.verifyTextPresent("Logout", false)
WebUI.closeBrowser()







