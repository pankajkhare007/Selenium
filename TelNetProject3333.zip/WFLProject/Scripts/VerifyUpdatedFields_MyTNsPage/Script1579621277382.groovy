
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.TelephoneNumber
import helper.GenericFunctions
import helper.Global
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'applicationLib.CommonLib.Login'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

WebUI.verifyTextPresent('Welcome to your SIP Portal', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Services/Services'))

CommonLib.handleLoadingImange(20)

GenericFunctions.clickOnLinkText("Telephone Numbers (TN)")

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(20)

Global.phoneNumber = TelephoneNumber.getFirstPhoneNumberFromTable()

WebUI.setText(findTestObject('Page_Telnetapp/searchTextBox'), Global.phoneNumber)



WebUI.click(findTestObject('Object Repository/Page_Telnetapp/applyButton'))
CommonLib.handleLoadingImange(20)

GenericFunctions.clickOnLinkText(Global.phoneNumber)

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/callerName'), 40)

String callName = "Test"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/MyTNs/callerName'), callName)

//String callNumber = "123456"+GenericFunctions.getRandomNumber()
//
//WebUI.setText(findTestObject('Object Repository/MyTNs/callerNumber'), callNumber)

String customerName = "Cust"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/MyTNs/customerName'), customerName)

WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton'))

CommonLib.handleLoadingImange(30)
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(30)
WebUI.setText(findTestObject('Page_Telnetapp/searchTextBox'), Global.phoneNumber)


GenericFunctions.clickOnLinkText(Global.phoneNumber)

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/callerName'), 40)

CommonLib.handleLoadingImange(30)

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/MyTNs/callerName'),"value"),callName)
//WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/MyTNs/callerNumber'),"value"),callNumber)
WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/MyTNs/customerName'),"value"),customerName)

//println(str)

CommonLib.logout()

WebUI.closeBrowser()

