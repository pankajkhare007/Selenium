import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.TelephoneNumber
import helper.GenericFunctions
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'applicationLib.CommonLib.LoginForExport'()

//GenericFunctions.waitForLinkClickable("Services")

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

//WebUI.waitForPageLoad(60)
//Thread.sleep(10000)

CommonLib.handleLoadingImange(60)

WebUI.verifyTextPresent('Welcome to your SIP Portal', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Object Repository/Services/Services'))

GenericFunctions.waitForLinkClickable("Telephone Numbers (TN)")
//CommonLib.handleLoadingImange(30)
//WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'), 30)

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'))
GenericFunctions.clickOnLinkText("Telephone Numbers (TN)")

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Services/exportButton'))

Thread.sleep(3000)

boolean flag = CommonLib.isFileDownloaded()

WebUI.verifyEqual(flag, true)

WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_TelephoneNumber'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_State'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_TelephoneNumber'), 0)

WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('Phone Number'), true)
//WebUI.verifyEqual(CommonLib.isHeaderColumnExist('In Service Date'), true)
//WebUI.verifyEqual(CommonLib.isHeaderColumnExist('Trunk Group'), true)
WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('Route ID Description'), true)
WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('Rate Center'), true)
WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('State'), true)
WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('Status'), true)
WebUI.verifyEqual(TelephoneNumber.isHeaderColumnExistOnTelephoneNumberPage('e911'), true)
/*
WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_TelephoneNumber'), 5)

WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_State'), 5)
WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_RateCenter'), 5)
WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/SearchFilter_e911'), 5)*/


CommonLib.logout()

WebUI.closeBrowser()

