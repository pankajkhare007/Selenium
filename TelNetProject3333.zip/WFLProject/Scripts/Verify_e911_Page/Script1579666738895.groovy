import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import applicationLib.CommonLib
import applicationLib.E911
import helper.GenericFunctions
import helper.Global
import applicationLib.TelephoneNumber

CustomKeywords.'applicationLib.CommonLib.LoginForExport'()
WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)
CommonLib.handleLoadingImange(60)
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 40)

CommonLib.handleLoadingImange(60)



WebUI.verifyElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)
WebUI.takeScreenshot()


WebUI.click(findTestObject('Object Repository/Page_Telnetapp/templateLink'))

//Thread.sleep(3000)
CommonLib.handleLoadingImange(60)

boolean isTemplateDownloaded = CommonLib.isFileDownloaded()

WebUI.verifyEqual(isTemplateDownloaded, true)


WebUI.click(findTestObject('Object Repository/Services/exportButton'))

//Thread.sleep(3000)
CommonLib.handleLoadingImange(60)

boolean isExported = CommonLib.isFileDownloaded()

WebUI.verifyEqual(isExported, true)

Global.phoneNumberFore911 = E911.getPhoneNumberWithoutRecordFromTable()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'),Global.phoneNumberFore911)
GenericFunctions.waitForLinkClickable(Global.phoneNumberFore911)
GenericFunctions.clickOnLinkText(Global.phoneNumberFore911)

//WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/customerName'), 20)

WebUI.waitForElementClickable(findTestObject('Object Repository/Page_Telnetapp/customerName'), 20)

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/customerName'), 5)
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/houseNumber'), 5)
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/houseNumberSuffix'), 5)
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Telnetapp/location'), 5)

String customerName = "Customer"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/customerName'), customerName)

String houseNumber = "2409"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/houseNumber'), houseNumber)



String location = "Loc"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/location'), location)


String streetName = "W Long Lake Rd"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/streetName'), streetName)

String city = "Troy"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/city'), city)

String state = "MI"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/state'), state)


String zipcode = "2"+ GenericFunctions.getRandomNumber()

TelephoneNumber.setTextInZipcode("48098")


WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/modalPopup'), 20)



WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton_e911_ConfirmationPopup'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton_e911_ConfirmationPopup'))

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton_e911_ConfirmationPopup'))

//Thread.sleep(8000)
CommonLib.handleLoadingImange(60)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))



WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(60)

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'),Global.phoneNumberFore911)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/applyButton'))

CommonLib.handleLoadingImange(60)

GenericFunctions.getDataFromTable("Phone Number", "Customer Name", Global.phoneNumberFore911)

WebUI.verifyEqual(GenericFunctions.getDataFromTable("Phone Number", "Customer Name", Global.phoneNumberFore911), customerName)

WebUI.verifyEqual(GenericFunctions.getDataFromTable("Phone Number", "House Number", Global.phoneNumberFore911), houseNumber)

WebUI.verifyEqual(GenericFunctions.getDataFromTable("Phone Number", "Location", Global.phoneNumberFore911), location)

WebUI.verifyEqual(GenericFunctions.getDataFromTable("Phone Number", "Street Name", Global.phoneNumberFore911), streetName)

CommonLib.logout()

WebUI.closeBrowser()
