import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import applicationLib.CommonLib as CommonLib
import applicationLib.TelephoneNumber
import helper.GenericFunctions
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'applicationLib.CommonLib.Login'()

WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Telnetapp/welcomeLabel_home'), 10)

CommonLib.handleLoadingImange(60)

WebUI.verifyTextPresent('Welcome to your SIP Portal', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Services/Services'))

GenericFunctions.waitForLinkClickable("Telephone Numbers (TN)")

//WebUI.click(findTestObject('Object Repository/Page_Telnetapp/TelephoneNumber'
GenericFunctions.clickOnLinkText("Telephone Numbers (TN)")

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/MyTNs'))

WebUI.waitForElementPresent(findTestObject('Object Repository/MyTNs/myTelephoneNumberTable'), 20)

CommonLib.handleLoadingImange(60)

TelephoneNumber.selectNoFrome911Column()

String sRedXTN = TelephoneNumber.getFirstPhoneNumberFromTable()
//println(sRedXTN)
GenericFunctions.clickOnLinkText(sRedXTN)

CommonLib.handleLoadingImange(60)

String customerName = "Customer"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/customerName'), customerName)

String houseNumber = "1000"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/houseNumber'), houseNumber)

//String homeNumberSuffix = GenericFunctions.getRandomNumber()

//WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/houseNumberSuffix'), homeNumberSuffix)

WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/prefixDD'), "W", false)

WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/postFixDD'), "N/A", false)

//WebUI.selectOptionByLabel(findTestObject('Object Repository/Page_Telnetapp/stateDD'), "CA", false)

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/stateDD'), "MI")

String location = "Loc"+GenericFunctions.getRandomNumber()

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/location'), location)

String city = "Troy"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/city'), city)

String streetName = "Long Lake Rd"

WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/streetName'), streetName)

String zipcode = "48098"

TelephoneNumber.setTextInZipcode(zipcode)
//WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/zipcode'), zipcode)

WebUI.click(findTestObject('Object Repository/trunkGroup/saveButton'))
WebUI.click(findTestObject('Object Repository/Page_Telnetapp/saveButton'))

CommonLib.handleLoadingImange(30)

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/e911'))

CommonLib.handleLoadingImange(30)


WebUI.setText(findTestObject('Object Repository/Page_Telnetapp/searchTextBox'), sRedXTN)

GenericFunctions.clickOnLinkText(sRedXTN)

CommonLib.handleLoadingImange(30)

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/customerName'), "value"), customerName)

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/houseNumber'), "value"), houseNumber)

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/zipcode1'), "value"), zipcode)

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/state1'), "value"), "MI")

WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Object Repository/Page_Telnetapp/streetName'), "value"), streetName)

WebUI.takeScreenshot()

//TelephoneNumber.scrollForCancelButton()

WebUI.click(findTestObject('Object Repository/Page_Telnetapp/cancelBtn'))
CommonLib.logout()
WebUI.closeBrowser()
