<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>//div[@class='modal-footer d-flex justify-content-center']//button[@class='btn telnet-btn-grey'][contains(text(),'Cancel')]</description>
   <name>E911_Cancel_Popup</name>
   <tag></tag>
   <elementGuidId>d4bc160b-257f-425f-9ac9-1fbe97e14bac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='modal-footer d-flex justify-content-center']//button[@class='btn telnet-btn-grey'][contains(text(),'Cancel')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
