<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ContinueBtn_TNConfirmation</name>
   <tag></tag>
   <elementGuidId>2f11c3b6-d373-459e-b0f1-c30eed4bf5df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='tnPowerConfirmationModal']//button[@class='btn telnet-btn-green'][contains(text(),'Continue')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
