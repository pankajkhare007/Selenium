<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>E911_Save_Popup</name>
   <tag></tag>
   <elementGuidId>df399803-bf47-4d2f-9e43-1453fdbcd397</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='modal-footer d-flex justify-content-center']//button[@class='btn telnet-btn-green'][contains(text(),'Save')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
