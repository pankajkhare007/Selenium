<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>table_Impersonate</name>
   <tag></tag>
   <elementGuidId>bc468f42-a3eb-4654-96f9-9dd8179299d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[contains(@id,'DataTables_Table')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
