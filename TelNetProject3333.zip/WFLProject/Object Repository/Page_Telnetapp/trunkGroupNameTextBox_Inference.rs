<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>trunkGroupNameTextBox_Inference</name>
   <tag></tag>
   <elementGuidId>9555396a-d413-4175-b8d4-a227b39c81dc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[contains(text(),'Trunk Group Name')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
