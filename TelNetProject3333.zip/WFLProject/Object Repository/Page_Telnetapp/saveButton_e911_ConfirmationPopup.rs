<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>saveButton_e911_ConfirmationPopup</name>
   <tag></tag>
   <elementGuidId>e032eb3e-b76b-4056-afcb-4473fa4c5bcc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='modal-footer']//button[@class='btn telnet-btn-green'][contains(text(),'Save')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
