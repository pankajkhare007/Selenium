<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cancelBtn_ManageSIPTrunks</name>
   <tag></tag>
   <elementGuidId>8b4ed1a0-27d6-4ded-b8d0-7e995702416a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='d-flex flex-row justify-content-center']//button[@class='btn telnet-btn-grey'][contains(text(),'Cancel')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
