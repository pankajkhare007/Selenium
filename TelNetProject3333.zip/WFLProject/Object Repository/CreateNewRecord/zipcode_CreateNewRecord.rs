<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>//div[@class='table-responsive detail-table']//input[@name='zipcode']</description>
   <name>zipcode_CreateNewRecord</name>
   <tag></tag>
   <elementGuidId>a984e62e-e9e3-44d4-834b-5951ab12aaca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='zipcode']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
