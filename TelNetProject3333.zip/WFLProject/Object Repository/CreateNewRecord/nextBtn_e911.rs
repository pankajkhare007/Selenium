<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nextBtn_e911</name>
   <tag></tag>
   <elementGuidId>def1e75b-a826-42a9-8da3-1970b8ed9ac0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='slide-item carousel-item active']//button[@class='e911-btn'][contains(text(),'Next')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
