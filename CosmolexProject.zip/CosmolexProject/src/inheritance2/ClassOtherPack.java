package inheritance2;

public class ClassOtherPack {
	
	public static void numberCall()
	{
		System.out.println("Different pack");
	}

}
