package DeleteAllItem;



import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class DeleteCalenderItem {
	
	static WebDriver driver;
	public static void main(String args[]) throws InterruptedException
	{
		System.setProperty("webdriver.gecko.driver", "lib/geckodriver.exe");
		driver= new FirefoxDriver();
		driver.get("https://law.cosmolex.com");
		//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		//driver.switchTo().
		Thread.sleep(15000);
		//waitForElementPresent(60, By.id("userName"));
		driver.findElement(By.id("userName")).sendKeys("mlakhani@cosmolex.com");
		driver.findElement(By.id("password")).sendKeys("Lakhani@2018");
		driver.findElement(By.xpath("//*[@value='Sign In']")).click();
		Actions action = new Actions(driver);
		waitForElementPresent(60, By.xpath("//*[@class='logoContainer']"));
		action.moveToElement(driver.findElement(By.xpath("//*[@class='logoContainer']"))).build().perform();
		//waitForElementPresent(60, By.linkText("Activities"));
		//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()='Activities']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='dijit_layout_TabContainer_1_tablist_dijit_layout_BorderContainer_21']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()='Details']")).click();
		Thread.sleep(5000);
		
//		String str = "/html/body/div[2]/div/div[2]/div[3]/div[2]/div[3]/div/div[3]/div/div/div[3]/div[4]/div/div/div[3]/div[2]/div/div/div/div[1]/div[3]/div[2]/div/div/div/span/i";
//		driver.findElement(By.xpath(str)).click();
//		Thread.sleep(5000);
//		
//		
//		driver.findElement(By.xpath("//*[@id='dijit_form_Select_18']/tbody/tr/td[1]")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[text()='All")).click();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//*[@id='dijit_form_Select_21']/tbody/tr/td[1]")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[text()='Mayuri Lakhani")).click();
//		Thread.sleep(5000);
		
		for(int i=0;i<10;i++)
		{
			List<WebElement> listEle=driver.findElements(By.xpath("//*[@class='day']"));
			for(int k=0;k<50;k++)
			{
				listEle.get(k).click();
				Thread.sleep(500);
			}
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='dijit_form_Button_88_label']")).click();
//			List<WebElement> listEle = driver.findElements(By.xpath("//*[text()='Delete']"));
//			listEle.get(2).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[text()='Yes']")).click();
			Thread.sleep(5000);
		}
		
	}
	public static void waitForElementPresent(int waitTime,By by)
	{
		//LocatorType locator =propObject.getLocatorType(proertiesValue);
		WebDriverWait driverWait = new WebDriverWait(driver, waitTime);
		driverWait.until(ExpectedConditions.presenceOfElementLocated(by));
		//alertPopup.accept();
		//Reporter.log("Element is present");
	}

}
