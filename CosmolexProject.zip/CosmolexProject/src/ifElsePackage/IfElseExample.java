package ifElsePackage;

public class IfElseExample {
	
	public static void main(String args[])
	{
		int i =20;
		if(i==10)
		{
			System.out.println("if block");
			System.out.println("if blockrrrr");
		}
		 if(i==20)
		{
			System.out.println("Else block");
		}
		
		 if(i==30)
		{
			System.out.println("Else block");
		}
	}

}
