package SwitchCaseExample;

public class SwitchCaseClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*int i = 30;
		switch(i)
		{
		case 12 :
			System.out.println("this is 12 block");
			//break;
		case 30 :
			System.out.println("this is 30 block");
			//break;
		case 5 :
			System.out.println("this is 5 block");
			//break;
		case 10 :
			System.out.println("this is 10 block");
			
			
			
			break;
		default :
			System.out.println("this is default block");
			break;
		
		}
		*/
		
		char ch='o';    
	    switch(ch)  
	    {  
	        case 'a':   
	           
	        case 'e':   
	            
	        case 'i':   
	            
	        case 'o':   
	             
	        case 'u':   
	            
	        case 'A':   
	            
	        case 'E':   
	              
	        case 'I':   
	             
	        case 'O':   
	             
	        case 'U':   
	            System.out.println("Vowel");  
	            break;  
	        default:   
	            System.out.println("Consonant");  
	    }

	}

}
