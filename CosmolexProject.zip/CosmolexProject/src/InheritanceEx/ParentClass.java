package InheritanceEx;

public class ParentClass {
	
	static int i =10;
	 static  void add()
	{
		System.out.println("This is method of parent class");
	}

}
