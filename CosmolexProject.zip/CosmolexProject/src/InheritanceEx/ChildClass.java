package InheritanceEx;
import inheritance2.*;
public class ChildClass extends ClassOtherPack
{
	
	public static void main(String args[])
	{
		
		add();
		numberCall();
		
		//System.out.println(i);
	}
	///overriding
	
	static  void add()
	{
		
		System.out.println("This is my add method of Child Class");
	}

}
