package deleteFolderPack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DelFolder {

	public static void main(String[] args) throws IOException {
		
		deleteFolder("Screenshots");
		
		
	}
	
	public static void deleteFolder(String folderName) throws IOException
	{
		

			String reportPath="C:\\"+folderName;
			//File file = new File(reportPath);
			Path path = Paths.get(reportPath);
			Files.walk(Paths.get("C:\\"+folderName))
            .filter(Files::isRegularFile)
            .map(Path::toFile)
            .forEach(File::delete);
			Files.delete(path);
	}

}
