package loopExample;

public class DoWhileEx {

	public static void main(String[] args) {
		int i=11;
		do
		{
			System.out.println(i);
			i++;
		}while(i<=10);
		
		

	}

}
