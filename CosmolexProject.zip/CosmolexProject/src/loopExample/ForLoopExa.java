package loopExample;

public class ForLoopExa {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		/*for(int i=0;i<=50;i++)
		{
			if(i%2==0)
				System.out.println("Even number  "+i);
			else
				System.out.println("odd number  "+i);
		}*/
		
		for(int i =0;i<=2;i++)
		{
			for(int j=1;j<=5;j++)
			{
				System.out.print(i);
				System.out.print(" "+j);
				System.out.println();
			}
		}
	}

}
