package ListPack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListClass {

	public static void main(String[] args) {
		List<Double> obj = new ArrayList<Double>();
		 obj.add(23.23);
		 obj.add(44.23);
		 obj.add(55.23);
		 obj.add(66.23);
		//double d= obj.get(0);
		 
	Iterator<Double> it =	obj.iterator();
	while(it.hasNext())
	{
		Object d1=it.next();
		System.out.println(d1);
		
	}
	
	
		
	}

}
