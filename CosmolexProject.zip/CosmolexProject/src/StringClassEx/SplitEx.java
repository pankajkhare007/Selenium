package StringClassEx;

public class SplitEx {
	
	public static void main(String args[])
	{
		String str="clientid : 2345";
		String arr[]=str.split(":");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		
		String str1="I am a good person";
		String strArr[]=str1.split("\\s",3);
		for(String fr:strArr)
		{
			System.out.println(fr);
		}
	}

}
