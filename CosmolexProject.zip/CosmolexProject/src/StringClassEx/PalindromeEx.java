package StringClassEx;

public class PalindromeEx {
	
	public static void main (String []args)
	{
		String actualString ="madam";
		String expectedString="";
		for(int i=actualString.length()-1;i>=0;i--)
		{
			char chr = actualString.charAt(i);
			expectedString=expectedString+chr;
		}
		if(actualString.equals(expectedString))
		{
			System.out.println("Word is palindrome");
		}
		else
			System.out.println("not palindrome");
	}

}
