package StringClassEx;

public class StartWithEndWith {

	public static void main(String[] args) {
		/*String str = "data updated successfully";
		System.out.println(str.startsWith("data"));
		System.out.println(str.endsWith("successfully"));*/

		String str1 = " good person ";
		System.out.println(str1);
		System.out.println(str1.trim());
		System.out.println(str1.trim().equals("good person"));
	}

}
