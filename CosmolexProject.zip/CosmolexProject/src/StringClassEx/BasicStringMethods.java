package StringClassEx;

public class BasicStringMethods {

	public static void main(String args[]) {
		String str = "Java class";
		String str1 = new String("java class");
		int len = str.length();
		System.out.println(len);

		if (str.equals(str1)) {
			System.out.println("if block");
		} else
			System.out.println("Else block");

		// System.out.println(str.equals(str1));
		// System.out.println(str.equalsIgnoreCase(str1));
		// System.out.println(str.toLowerCase());
		// String stringUpper=str.toUpperCase();

		//// Split method

		// String arr[]=str.split("\\s");
		// for(String rr1:arr)
		// {
		// System.out.println(rr1);
		// }
		//
		// for(int i=0;i<arr.length;i++)
		// {
		// System.out.println(arr[i]);
		// }
		// String projectidWithName="autmatonproject(12345)";
		// String projectArr[]=projectidWithName.split("\\(");
		// System.out.println(projectArr[1]);
		// String projectid=projectArr[1].replace(")", "");
		// System.out.println("Project id : "+projectid);
		/// another split

		/*
		 * String str11 = "This is a selenium class"; String
		 * arr11[]=str11.split("\\s",3); System.out.println(arr11.length); for(String
		 * sr:arr11) { System.out.println(sr); }
		 * 
		 * str11=str11.replaceAll("s", "e");
		 * 
		 * System.out.println(str11);
		 * 
		 * boolean b = str11.contains("selenium"); System.out.println(b);
		 * if(str11.contains("selenium")) { System.out.println("if block"); }
		 * 
		 * String str44 = "selenium"; String str55 = "class"; String str34 =
		 * str44.concat(str55); System.out.println(str34);
		 */

	}

}
