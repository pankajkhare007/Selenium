package TestngPackage;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Class2 {
	
	@Test
	public void class2M1()
	{
		System.out.println("class2M1 method");
	}
	@BeforeTest
	public void m2()
	{
		System.out.println("Before Test");
	}
	
	@BeforeSuite
	public void beforSuitmethod()
	{
		System.out.println("Before Suite Method");
	}
	
	@BeforeClass
	public void beforeClassMethod()
	{
		System.out.println("Before Class Method");
	}
	

}
