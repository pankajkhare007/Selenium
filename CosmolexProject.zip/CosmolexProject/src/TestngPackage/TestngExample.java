package TestngPackage;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class TestngExample {
	
	@Test(groups="regression")
	public void m1()
	{
		System.out.println("Test Method");
		assertEquals(100, 100);
		
		System.out.println("Test Method verified");
	}
	
	
	@Test(groups="regression")
	public void am2()
	{
		System.out.println("Test Method");
	}
	@Test(groups="smoke")
	public void m3()
	{
		System.out.println("Test Method");
	}

}
