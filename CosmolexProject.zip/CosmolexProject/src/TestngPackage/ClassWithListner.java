package TestngPackage;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(TestngPackage.ListnerClass.class)
public class ClassWithListner {
	
	@Test
	public void m1()
	{
		System.out.println("Test Method");
		assertEquals(100, 2000);
	}

}
