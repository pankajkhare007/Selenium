package MethodExplanation;

public class ClassABC {

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassABC obj = new ClassABC();
		obj.add(12, 23.33);

	}*/
	public static void add(int i,double d)
	{
		int c = i+(int)d;
		System.out.println(c);
	}

}
