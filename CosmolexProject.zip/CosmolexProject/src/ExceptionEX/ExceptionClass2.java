package ExceptionEX;

public class ExceptionClass2 {
	public void add()
	{
		try
		{
			int i=50/0;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		}
		finally
		{
			System.out.println("This is my finally code");
		}
	
	}

}
