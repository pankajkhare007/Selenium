package ExceptionEX;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionClass {

	public static void main(String[] args) throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		FileInputStream in = new FileInputStream(new File(""));
	}
	//
	
}
