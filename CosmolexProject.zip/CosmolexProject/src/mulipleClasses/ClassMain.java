package mulipleClasses;
import MethodExplanation.*;

public class ClassMain {
	public static void main(String args[])
	{
		ClassNormal cn = new ClassNormal();
		cn.add();
		ClassNormal.staticMethod();
	//	ClassABC obj = new ClassABC();
		ClassABC.add(23, 34);
	}
}
