package mulipleClasses;

public class ClassNormal {
	
	public void add()
	{
		System.out.println(10+20);
	}
	public static void staticMethod()
	{
		System.out.println("Static Method");
	}

}
