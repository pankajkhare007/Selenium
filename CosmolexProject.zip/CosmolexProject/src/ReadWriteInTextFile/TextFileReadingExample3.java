package ReadWriteInTextFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
/**
 * This program demonstrates how to read characters from a text file
 * using a BufferedReader for efficiency.
 * @author www.codejava.net
 *
 */
public class TextFileReadingExample3 {
	

    public static String getSessionText() {
    	 String txtFile=null;
        try {
            FileReader reader = new FileReader("TestData/SessionID.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
 
            String line;
                      
 
            while ((line = bufferedReader.readLine()) != null) {
               // System.out.println(line);
                txtFile=line;
                
            }
            reader.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(txtFile);
        return txtFile;
    }
    
    public static String getURLText() {
   	 String txtFile=null;
       try {
           FileReader reader = new FileReader("TestData/URLText.txt");
           BufferedReader bufferedReader = new BufferedReader(reader);

           String line;
                     

           while ((line = bufferedReader.readLine()) != null) {
              // System.out.println(line);
               txtFile=line;
               
           }
           reader.close();

       } catch (IOException e) {
           e.printStackTrace();
       }
       System.out.println(txtFile);
       return txtFile;
   }
 
}
