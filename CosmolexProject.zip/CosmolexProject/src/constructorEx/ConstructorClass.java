package constructorEx;

public class ConstructorClass {
	
	public static void main(String args[])
	{
		ConstructorClass obj=new ConstructorClass();
	}
	
	public ConstructorClass()
	{
		System.out.println("Default Constructor");
	}

}
