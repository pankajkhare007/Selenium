package InterfacePack;

public class Square implements AreaEx
{

	@Override
	public void area() {
		// TODO Auto-generated method stub
		int side=10;
		int area = side*side;
		System.out.println(area);
				
	}

}
