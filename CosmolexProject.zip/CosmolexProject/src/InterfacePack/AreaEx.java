package InterfacePack;

public interface AreaEx {
	
	void area();

}
