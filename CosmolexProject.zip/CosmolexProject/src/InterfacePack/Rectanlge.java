package InterfacePack;

public class Rectanlge implements AreaEx
{

	@Override
	public void area() {
		int widht=10;
		int len=20;
		int area = widht*len;
		System.out.println(area);
		
	}

}
