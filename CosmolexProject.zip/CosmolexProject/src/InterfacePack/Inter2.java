	package InterfacePack;

public interface Inter2 {
	void m4();
	void m5();
}
