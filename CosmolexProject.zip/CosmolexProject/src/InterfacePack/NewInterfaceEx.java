package InterfacePack;

public interface NewInterfaceEx {
	

}
