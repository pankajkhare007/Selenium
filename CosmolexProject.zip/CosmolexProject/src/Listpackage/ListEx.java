package Listpackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListEx {
	
	public static void main(String args[])
	{
		List<Integer> l = new ArrayList<Integer>();
		l.add(10);
		l.add(13);
		l.add(133);
		/*for(int i =0;i<l.size();i++)
		{
			System.out.println(l.get(i));
		}*/
		/*for(int bl : l)
		{
			System.out.println(bl);
		}*/
		
		Iterator<Integer> it=l.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	}

}
