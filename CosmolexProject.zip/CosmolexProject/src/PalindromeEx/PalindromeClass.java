package PalindromeEx;

public class PalindromeClass {
	
	public static void main(String args[])
	{
		String str = "this is my class ";
		System.out.println(str.substring(4));
		System.out.println(str.substring(1,4));
		
//		if(str.isEmpty())
//		{
//			System.out.println("this statement is valid");
//		}
//		else
//			System.out.println("somthing wrong");
//		String result = "";
//		for(int i = str.length()-1;i>=0;i--)
//		{
//			char chr=str.charAt(i);
//			result = result+chr;
//			
//		}
//		
//		if(str.equals(result))
//		{
//			System.out.println("This is planidrom");
//		}
//		else
//		{
//			System.out.println("This is not planidrom");
//		}
	}

}
