package DataFromKeyword;

import java.util.Scanner;

class Input {
    public static void main(String[] args) {
    	
    	Scanner input = new Scanner(System.in);
    	
    	System.out.print("Enter an integer: ");
    	String number = input.next();
    	System.out.println("You entered " + number);
    }
}