package abstractClass;

public abstract  class AbstractClassEx {
	
	public void m1()
	{
		
	}
	public void m2()
	{
		
	}
	abstract  void m3();

}
