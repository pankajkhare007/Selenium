package abstractClass;

public class MainClass extends AbstractClassEx {

	
	
	
	public static void main(String args[])
	{
		MainClass obj = new MainClass();
		obj.m3();
		obj.m4();
		AbstractClassEx obj1 = new MainClass();
		obj1.m3();
	}

	@Override
	void m3() {
		System.out.println("M3");
		
	}

	void m4() {
		
		System.out.println("M4");
	}


	

}
